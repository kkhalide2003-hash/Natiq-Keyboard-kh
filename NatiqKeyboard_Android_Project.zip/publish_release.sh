#!/usr/bin/env bash
set -euo pipefail

: "${GITHUB_TOKEN:?GITHUB_TOKEN is required}"
owner="kkhalide2003-hash"
repo="Natiq-Keyboard-kh"
tag="build-34621846387"
artifact_id="10273210966"
api="https://api.github.com/repos/${owner}/${repo}"
tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT

auth=(-H "Authorization: Bearer ${GITHUB_TOKEN}" -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28")
curl -fsSL "${auth[@]}" "$api/actions/artifacts/${artifact_id}/zip" -o "$tmpdir/artifact.zip"
unzip -j -q "$tmpdir/artifact.zip" '*.apk' -d "$tmpdir"
apk="$(find "$tmpdir" -maxdepth 1 -type f -name '*.apk' -print -quit)"
test -n "$apk"

release_status="$(curl -sS "${auth[@]}" -o "$tmpdir/release.json" -w '%{http_code}' "$api/releases/tags/$tag")"
if [ "$release_status" = "404" ]; then
  curl -fsSL -X POST "${auth[@]}" -H "Content-Type: application/json" \
    -d "$(python3 - <<PY
import json
print(json.dumps({
  'tag_name': '$tag',
  'name': 'Natiq Keyboard build 34621846387',
  'body': 'أحدث نسخة تجريبية من تطبيق نَطِق.\\nفعّل لوحة المفاتيح من إعدادات Android بعد التثبيت.\\nهذا الإصدار مبني من تشغيل GitHub Actions رقم 34621846387.',
  'make_latest': True,
}))
PY
)" "$api/releases" > "$tmpdir/release.json"
elif [ "$release_status" != "200" ]; then
  cat "$tmpdir/release.json" >&2
  exit 1
fi

release_id="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["id"])' "$tmpdir/release.json")"
asset_id="$(curl -fsSL "${auth[@]}" "$api/releases/$release_id/assets?per_page=100" | python3 -c 'import json,sys; items=json.load(sys.stdin); print(next((str(x["id"]) for x in items if x.get("name")=="NatiqKeyboard.apk"), ""))')"
if [ -n "$asset_id" ]; then
  curl -fsSL -X DELETE "${auth[@]}" "$api/releases/assets/$asset_id"
fi
curl -fsSL -X POST "${auth[@]}" \
  -H "Content-Type: application/vnd.android.package-archive" \
  --data-binary "@$apk" \
  "$api/releases/$release_id/assets?name=NatiqKeyboard.apk" > "$tmpdir/asset.json"
python3 - "$tmpdir/asset.json" <<'PY'
import json, sys
asset = json.load(open(sys.argv[1]))
if asset.get('name') != 'NatiqKeyboard.apk':
    raise SystemExit(f"Unexpected release asset: {asset}")
print(asset.get('browser_download_url', ''))
PY
