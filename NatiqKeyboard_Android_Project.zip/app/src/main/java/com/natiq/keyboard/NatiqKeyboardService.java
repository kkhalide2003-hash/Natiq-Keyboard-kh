package com.natiq.keyboard;

import android.inputmethodservice.InputMethodService;
import android.graphics.Color;
import android.graphics.Typeface;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Locale;

public class NatiqKeyboardService extends InputMethodService implements TextToSpeech.OnInitListener {
    private TextToSpeech speech;
    private boolean arabic = true;
    private final int navy = Color.rgb(8, 31, 56);
    private final int blue = Color.rgb(20, 90, 150);

    @Override
    public void onCreate() {
        super.onCreate();
        speech = new TextToSpeech(this, this);
    }

    @Override
    public View onCreateInputView() {
        LinearLayout keyboard = new LinearLayout(this);
        keyboard.setOrientation(LinearLayout.VERTICAL);
        keyboard.setPadding(6, 6, 6, 8);
        keyboard.setBackgroundColor(navy);

        LinearLayout controls = row();
        addKey(controls, "عربي / English", v -> arabic = !arabic, blue, 2.2f);
        addKey(controls, "⌫", v -> backspace(), blue, 1f);
        addKey(controls, "↵", v -> enter(), blue, 1f);
        keyboard.addView(controls);

        String[] arabicRows = {
            "ض ص ث ق ف غ ع ه خ ح ج د ذ",
            "ش س ي ب ل ا ت ن م ك ط ظ",
            "ئ ء ؤ ر ة و ز س ج ح"
        };
        for (String letters : arabicRows) {
            LinearLayout line = row();
            for (String letter : letters.split(" ")) {
                addLetter(line, letter);
            }
            keyboard.addView(line);
        }

        LinearLayout marks = row();
        for (String mark : new String[]{"َ", "ِ", "ُ", "ْ", "ّ", "ً", "ٍ", "ٌ"}) {
            addLetter(marks, mark);
        }
        keyboard.addView(marks);

        LinearLayout bottom = row();
        addKey(bottom, "English", v -> arabic = false, Color.rgb(40, 115, 95), 1.5f);
        addKey(bottom, "المسافة", v -> commit(" "), blue, 3f);
        addKey(bottom, "عربي", v -> arabic = true, Color.rgb(40, 115, 95), 1.5f);
        keyboard.addView(bottom);
        return keyboard;
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, 2, 0, 2);
        return row;
    }

    private void addLetter(LinearLayout row, String letter) {
        addKey(row, letter, v -> {
            commit(letter);
            speech.speak(letter, TextToSpeech.QUEUE_FLUSH, null, "natiq-letter");
        }, Color.rgb(255, 255, 255), 1f);
    }

    private void addKey(LinearLayout row, String label, View.OnClickListener listener, int color, float weight) {
        Button key = new Button(this);
        key.setText(label);
        key.setTextColor(color == Color.WHITE ? navy : Color.WHITE);
        key.setTextSize(label.length() > 3 ? 12 : 18);
        key.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        key.setAllCaps(false);
        key.setPadding(0, 0, 0, 0);
        key.setOnClickListener(listener);
        row.addView(key, new LinearLayout.LayoutParams(0, 52, weight));
    }

    private void commit(String text) {
        InputConnection connection = getCurrentInputConnection();
        if (connection != null) connection.commitText(text, 1);
    }

    private void backspace() {
        InputConnection connection = getCurrentInputConnection();
        if (connection == null) return;
        CharSequence before = connection.getTextBeforeCursor(2, 0);
        if (before != null && before.length() > 0) connection.deleteSurroundingText(1, 0);
    }

    private void enter() {
        InputConnection connection = getCurrentInputConnection();
        if (connection != null) connection.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) speech.setLanguage(new Locale("ar"));
    }

    @Override
    public void onDestroy() {
        if (speech != null) {
            speech.stop();
            speech.shutdown();
        }
        super.onDestroy();
    }
}