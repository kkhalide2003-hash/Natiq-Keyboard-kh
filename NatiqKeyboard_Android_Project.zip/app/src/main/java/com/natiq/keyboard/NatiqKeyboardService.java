package com.natiq.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class NatiqKeyboardService extends InputMethodService implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private boolean english = false;
    private final String arabic = "ابتثجحخدذرزسشصضطظعغفقكلمنهويءأإآةى";
    private final String latin = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final String marks = "َُِْ";

    @Override public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, this);
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ar", "SA"));
    }

    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(8, 8, 8, 8);
        root.setBackgroundColor(Color.rgb(7, 26, 47));

        LinearLayout toolbar = row();
        Button title = button("نَطِق", 0);
        title.setTextColor(Color.WHITE);
        toolbar.addView(title, weight(1));
        toolbar.addView(button("⌫", 50, v -> getCurrentInputConnection().deleteSurroundingText(1, 0)));
        toolbar.addView(button(english ? "ع" : "EN", 56, v -> { english = !english; setInputView(onCreateInputView()); }));
        root.addView(toolbar);
        addKeys(root, english ? latin : arabic);

        LinearLayout actions = row();
        for (String mark : new String[]{"َ", "ِ", "ُ", "ْ"}) actions.addView(button(mark, 44, v -> commitAndSpeak(mark)));
        actions.addView(button("مسافة", 0, v -> {
            String before = getCurrentInputConnection().getTextBeforeCursor(80, 0);
            getCurrentInputConnection().commitText(" ", 1);
            if (before != null && !before.trim().isEmpty()) speak(before.trim().split("\\s+")[before.trim().split("\\s+").length - 1]);
        }), weight(1));
        actions.addView(button("↵", 46, v -> getCurrentInputConnection().commitText("\n", 1)));
        root.addView(actions);
        return root;
    }

    private void addKeys(LinearLayout root, String values) {
        LinearLayout current = null;
        for (int i = 0; i < values.length(); i++) {
            if (i % 7 == 0) { current = row(); root.addView(current); }
            final String value = String.valueOf(values.charAt(i));
            current.addView(button(value, 0, v -> commitAndSpeak(value)), weight(1));
        }
    }

    private void commitAndSpeak(String value) {
        getCurrentInputConnection().commitText(value, 1);
        speak(!english && value.length() == 1 && marks.indexOf(value) < 0 ? value + "َ" : value);
    }

    private void speak(String value) {
        if (tts != null) {
            tts.setLanguage(english ? Locale.US : new Locale("ar", "SA"));
            tts.speak(value, TextToSpeech.QUEUE_FLUSH, null, "natiq-key");
        }
    }

    private LinearLayout row() { LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER); return row; }
    private Button button(String text, int width) { return button(text, width, v -> {}); }
    private Button button(String text, int width, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setTextSize(text.length() > 3 ? 11 : 18); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setMinHeight(46); b.setOnClickListener(listener); b.setPadding(2, 0, 2, 0); return b;
    }
    private LinearLayout.LayoutParams weight(float value) { return new LinearLayout.LayoutParams(0, 48, value); }
    private LinearLayout.LayoutParams weight(int value) { return new LinearLayout.LayoutParams(value, 48); }

    @Override public void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}