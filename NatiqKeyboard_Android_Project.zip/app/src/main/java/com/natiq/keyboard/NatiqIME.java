package com.natiq.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.graphics.Color;
import android.content.*;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.util.*;

public class NatiqIME extends InputMethodService {
 TextToSpeech tts; boolean dark=false; float rate=.85f;
 LinearLayout root, keys; TextView title;
 final String[] AR={"ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي","ء","أ","إ","آ","ة","ى"};
 final String[] DI={"َ","ُ","ِ","ْ","ّ","ً","ٌ","ٍ"};
 final String[] EN="QWERTYUIOPASDFGHJKLZXCVBNM".split("");

 @Override public void onCreate(){ super.onCreate(); tts=new TextToSpeech(this,status->{ if(status==TextToSpeech.SUCCESS){tts.setLanguage(new Locale("ar","SA")); tts.setSpeechRate(rate);}}); }
 @Override public View onCreateInputView(){ build(); return root; }

 void build(){
   root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(8,8,8,8); styleRoot();
   LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
   title=new TextView(this); title.setText("🔊 نَطِق"); title.setTextSize(18); title.setPadding(8,4,8,4);
   bar.addView(title,new LinearLayout.LayoutParams(0,48,1));
   Button mode=btn("🌙"); mode.setOnClickListener(v->{dark=!dark;styleRoot();});
   Button speak=btn("🔊"); speak.setOnClickListener(v->speakCurrentWord());
   bar.addView(speak); bar.addView(mode); root.addView(bar);

   keys=new LinearLayout(this); keys.setOrientation(LinearLayout.VERTICAL); root.addView(keys,new LinearLayout.LayoutParams(-1,0,1));
   makeRow(AR, true); makeRow(DI, true); makeRow(EN, false);

   LinearLayout actions=new LinearLayout(this);
   Button left=btn("◀"); left.setOnClickListener(v->move(-1));
   Button right=btn("▶"); right.setOnClickListener(v->move(1));
   Button del=btn("⌫"); del.setOnClickListener(v->delete());
   Button space=btn("مسافة 🔊"); space.setOnClickListener(v->spaceAndSpeak());
   actions.addView(left,new LinearLayout.LayoutParams(0,54,1)); actions.addView(right,new LinearLayout.LayoutParams(0,54,1));
   actions.addView(del,new LinearLayout.LayoutParams(0,54,1)); actions.addView(space,new LinearLayout.LayoutParams(0,54,2));
   root.addView(actions);
 }
 Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); return b; }

 void makeRow(String[] arr, boolean ar){
   LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
   for(String c:arr){ Button b=btn(c); b.setTextSize(ar?22:18); b.setOnClickListener(v->press(c,ar));
     row.addView(b,new LinearLayout.LayoutParams(0,50,1)); }
   keys.addView(row);
 }
 void press(String c, boolean ar){
   InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
   ic.commitText(c,1);
   if(ar){
     String mode = "َ";
     speak(c+mode);
   }else speak(c);
 }
 void spaceAndSpeak(){
   InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
   CharSequence cs=ic.getTextBeforeCursor(80,0); String s=cs==null?"":cs.toString();
   String word=s.replaceAll("^.*\\s+","");
   ic.commitText(" ",1);
   if(!word.isEmpty()) speak(word);
 }
 void speakCurrentWord(){
   InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
   CharSequence s=ic.getTextBeforeCursor(80,0); if(s!=null){String w=s.toString().replaceAll("^.*\\s+",""); if(!w.isEmpty())speak(w);}
 }
 void speak(String s){
   if(tts==null||s==null||s.isEmpty())return;
   tts.stop(); tts.setSpeechRate(rate);
   boolean en=s.matches(".*[A-Za-z].*");
   tts.setLanguage(en?Locale.US:new Locale("ar","SA"));
   tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"natiq");
 }
 void delete(){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.deleteSurroundingText(1,0);}
 void move(int d){
   InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
   // Most IMEs cannot directly move the cursor through InputConnection on all apps;
   // send directional key events for broad compatibility.
   int key=d<0?KeyEvent.KEYCODE_DPAD_LEFT:KeyEvent.KEYCODE_DPAD_RIGHT;
   ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,key)); ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,key));
 }
 void styleRoot(){
   if(root==null)return;
   root.setBackgroundColor(Color.parseColor(dark?"#0B1020":"#EEF2F7"));
   if(title!=null)title.setTextColor(Color.parseColor(dark?"#F7F9FC":"#111827"));
 }
 @Override public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}