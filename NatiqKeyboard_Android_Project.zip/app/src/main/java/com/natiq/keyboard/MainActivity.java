package com.natiq.keyboard;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, this);
        WebView view = new WebView(this);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        view.addJavascriptInterface(new Bridge(), "Android");
        view.loadUrl("file:///android_asset/index.html");
        setContentView(view);
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ar", "SA"));
    }

    private void speak(String value) {
        if (tts != null && value != null && !value.trim().isEmpty())
            tts.speak(value, TextToSpeech.QUEUE_FLUSH, null, "natiq-main");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface public void speak(String value) { MainActivity.this.speak(value); }
        @JavascriptInterface public void copy(String value) {
            ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            manager.setPrimaryClip(ClipData.newPlainText("نَطِق", value));
            Toast.makeText(MainActivity.this, "تم نسخ النص", Toast.LENGTH_SHORT).show();
        }
    }
}