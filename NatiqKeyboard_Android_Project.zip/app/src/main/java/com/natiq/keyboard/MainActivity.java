package com.natiq.keyboard;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private EditText editor;
    private TextToSpeech speech;
    private int blue = Color.rgb(20, 90, 150);
    private int navy = Color.rgb(8, 31, 56);

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        speech = new TextToSpeech(this, this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setBackgroundColor(Color.rgb(245, 248, 252));

        TextView title = new TextView(this);
        title.setText("نَطِق");
        title.setTextColor(navy);
        title.setTextSize(30);
        title.setGravity(Gravity.RIGHT);
        title.setTypeface(null, 1);
        root.addView(title, fullWidth(58));

        TextView subtitle = new TextView(this);
        subtitle.setText("تدريب على الكتابة والنطق ولوحة مفاتيح عربية تعمل في كل التطبيقات");
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.RIGHT);
        root.addView(subtitle, fullWidth(48));

        editor = new EditText(this);
        editor.setHint("اكتب هنا بالعربية أو English...");
        editor.setTextSize(23);
        editor.setGravity(Gravity.TOP | Gravity.RIGHT);
        editor.setPadding(20, 18, 20, 18);
        editor.setMinLines(7);
        editor.setBackgroundColor(Color.WHITE);
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, 18, 0, 8);
        addAction(actions, "قراءة", v -> speak(editor.getText().toString()));
        addAction(actions, "إيقاف", v -> speech.stop());
        addAction(actions, "نسخ", v -> copyText());
        addAction(actions, "مسح", v -> editor.setText(""));
        root.addView(actions, fullWidth(58));

        Button keyboard = new Button(this);
        keyboard.setText("تفعيل لوحة نَطِق في إعدادات Android");
        keyboard.setTextColor(Color.WHITE);
        keyboard.setBackgroundColor(blue);
        keyboard.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(keyboard, fullWidth(58));

        TextView note = new TextView(this);
        note.setText("بعد التفعيل، اختر نَطِق من أي حقل كتابة عبر زر تبديل لوحة المفاتيح.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        root.addView(note, fullWidth(42));

        setContentView(root);
    }

    private LinearLayout.LayoutParams fullWidth(int height) {
        return new LinearLayout.LayoutParams(-1, height);
    }

    private void addAction(LinearLayout row, String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setOnClickListener(listener);
        row.addView(button, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void copyText() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("نَطِق", editor.getText()));
        Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
    }

    private void speak(String text) {
        if (text.trim().isEmpty()) return;
        speech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "natiq-text");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            speech.setLanguage(new Locale("ar"));
        }
    }

    @Override
    protected void onDestroy() {
        if (speech != null) {
            speech.stop();
            speech.shutdown();
        }
        super.onDestroy();
    }
}