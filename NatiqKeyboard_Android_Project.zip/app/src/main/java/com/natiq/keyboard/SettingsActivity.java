package com.natiq.keyboard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class SettingsActivity extends Activity {
 @Override public void onCreate(Bundle b){
   super.onCreate(b);
   LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,32,32,32);
   TextView t=new TextView(this); t.setText("نَطِق\n\nلوحة إملاء تساعدك على سماع صوت الحرف داخل المقطع ثم الكلمة كاملة.\n\nفعّل لوحة نَطِق من إعدادات لوحة المفاتيح في الهاتف.");
   t.setTextSize(20); t.setGravity(Gravity.CENTER);
   Button open=new Button(this); open.setText("فتح إعدادات لوحات المفاتيح");
   open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
   l.addView(t,new LinearLayout.LayoutParams(-1,0,1)); l.addView(open);
   setContentView(l);
 }
}