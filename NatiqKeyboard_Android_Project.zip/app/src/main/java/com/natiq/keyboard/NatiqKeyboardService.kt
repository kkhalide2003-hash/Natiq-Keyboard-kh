package com.natiq.keyboard

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class NatiqKeyboardService : InputMethodService() {
    private var arabic = true
    private val arabicKeys = listOf("ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي")
    private val englishKeys = "QWERTYUIOPASDFGHJKLZXCVBNM".map { it.toString() }

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        arabic = true
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(8, 8, 8, 10)
        root.setBackgroundColor(Color.rgb(13, 27, 32))
        val keys = if (arabic) arabicKeys else englishKeys
        keys.chunked(8).forEach { rowKeys ->
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER
            rowKeys.forEach { key -> row.addView(button(key) { currentInputConnection?.commitText(key, 1) }) }
            root.addView(row)
        }
        val controls = LinearLayout(this)
        controls.gravity = Gravity.CENTER
        controls.addView(button("⇧") { arabic = !arabic; setInputView(buildKeyboard()) })
        controls.addView(button("مسافة") { currentInputConnection?.commitText(" ", 1) }, 3)
        controls.addView(button("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) })
        controls.addView(button("↵") { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)) })
        root.addView(controls)
        return root
    }

    private fun button(label: String, action: () -> Unit, weight: Int = 1): Button {
        val button = Button(this)
        button.text = label
        button.textSize = if (label.length > 2) 12f else 18f
        button.setTextColor(Color.WHITE)
        button.setBackgroundColor(Color.rgb(27, 58, 59))
        button.setOnClickListener { action() }
        button.layoutParams = LinearLayout.LayoutParams(0, 52, weight).apply { setMargins(3, 3, 3, 3) }
        return button
    }
}
